COPY product_orders FROM '/Users/danielsullivan/LinkedIn Learning/advanced_sql_developers/data/product_orders.csv' DELIMITER ',' CSV HEADER;
COPY products FROM '/Users/danielsullivan/LinkedIn Learning/advanced_sql_developers/data/products.csv' DELIMITER ',' CSV HEADER;
COPY orders FROM '/Users/danielsullivan/LinkedIn Learning/advanced_sql_developers/data/orders.csv' DELIMITER ',' CSV HEADER;
COPY customers FROM '/Users/danielsullivan/LinkedIn Learning/advanced_sql_developers/data/customers.csv' DELIMITER ',' CSV HEADER;
